//  ViewController.swift
//  Personality Quiz
//
//  Created by Aneet Kaur on 22/07/25.
//

import UIKit

class IntroductionViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

